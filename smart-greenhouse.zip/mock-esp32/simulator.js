// Mock ESP32 simulator — SDIGF Phase 1
//
// Stands in for the real ESP32-WROOM-32E while hardware is unavailable.
// It:
//   1. Polls the main server for the current desired actuator state
//      (exactly what the real firmware would poll a relay/servo target from).
//   2. Evolves an internal physical model of the greenhouse (temp, humidity,
//      light, water, gas, rain) that reacts to those actuator states, so
//      Claude / the dashboard can see cause -> effect during research runs.
//   3. POSTs a sensor JSON payload to /api/ingest in exactly the shape the
//      real firmware would send, using the same sensor keys as the hardware
//      wiring documentation (rain, gas_mq135, water_level_1/2, ldr_inner/outer,
//      dht11_inner/outer, bmp280_inner/outer).
//
// Swap this file out for real ESP32 firmware later without touching the
// server or the MCP server — the JSON contract is the integration point.

const SERVER_URL = process.env.SDIGF_SERVER_URL || "http://localhost:3000";
const DEVICE_ID = process.env.SDIGF_DEVICE_ID || "esp32-mock-01";
const TICK_MS = parseInt(process.env.SDIGF_TICK_MS || "4000", 10);
const DAY_CYCLE_MIN = parseFloat(process.env.SDIGF_DAY_CYCLE_MINUTES || "20"); // compressed day/night cycle for testing

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const lerp = (a, b, t) => a + (b - a) * t;
const noise = (amp) => (Math.random() * 2 - 1) * amp;

// ---- internal physical state (continuous, floats) ----
const state = {
  startedAt: Date.now(),
  outerTemp: 29,
  outerHumidity: 50,
  innerTemp: 33,
  innerHumidity: 58,
  outerPressure: 1010,
  innerPressure: 1010.5,
  ldrOuter: 60,   // % ambient brightness
  ldrInner: 35,
  rainPercent: 0,
  isRaining: false,
  waterLevel1: 50,
  waterLevel2: 45,
  gasPpm: 400,
};

let actuators = {
  south_fan: false,
  north_fan: false,
  storage_lights: false,
  croom_lights: false,
  green_area_lights: false,
  water_pump: false,
  window_servo: 0,
  roof_servo: 0,
};

async function pollActuators() {
  try {
    const res = await fetch(`${SERVER_URL}/api/actuators`);
    const data = await res.json();
    if (data.ok) actuators = data.state;
  } catch (err) {
    console.error("[mock-esp32] failed to poll actuators:", err.message);
  }
}

function dayCyclePhase() {
  // 0..1 sawtooth across DAY_CYCLE_MIN minutes, mapped to a sine wave so
  // brightness/temperature rise and fall smoothly like an actual day.
  const elapsedMin = (Date.now() - state.startedAt) / 60000;
  const phase = (elapsedMin % DAY_CYCLE_MIN) / DAY_CYCLE_MIN; // 0..1
  return Math.sin(phase * Math.PI * 2 - Math.PI / 2); // -1 (night) .. 1 (midday)
}

function tickPhysics() {
  const sun = dayCyclePhase(); // -1..1

  // ---- outdoor baseline driven by the compressed day cycle ----
  const targetOuterTemp = 27 + sun * 6; // 21..33C
  const targetOuterBrightness = 50 + sun * 48; // ~2..98%
  state.outerTemp = lerp(state.outerTemp, targetOuterTemp, 0.08) + noise(0.15);
  state.ldrOuter = clamp(lerp(state.ldrOuter, targetOuterBrightness, 0.15) + noise(1.5), 0, 100);

  // ---- rain: random onset/offset ----
  if (!state.isRaining && Math.random() < 0.01) state.isRaining = true;
  if (state.isRaining && Math.random() < 0.04) state.isRaining = false;
  const targetRain = state.isRaining ? 70 + noise(15) : 0;
  state.rainPercent = clamp(lerp(state.rainPercent, targetRain, 0.3), 0, 100);
  if (state.isRaining) {
    state.outerHumidity = clamp(state.outerHumidity + 1.2, 0, 100);
    state.ldrOuter = clamp(state.ldrOuter - 15, 0, 100);
  } else {
    const targetOuterHumidity = 55 - sun * 12; // drier at midday
    state.outerHumidity = clamp(lerp(state.outerHumidity, targetOuterHumidity, 0.05) + noise(0.5), 15, 100);
  }

  // ---- venting: fans + servo aperture speed up inner/outer equilibration ----
  const fanBoost = (actuators.south_fan ? 0.5 : 0) + (actuators.north_fan ? 0.5 : 0);
  const roofOpen = clamp((actuators.roof_servo || 0) / 180, 0, 1);
  const windowOpen = clamp((actuators.window_servo || 0) / 180, 0, 1);
  const ventFactor = clamp(0.03 + fanBoost * 0.08 + roofOpen * 0.06 + windowOpen * 0.04, 0.03, 0.35);

  // greenhouse effect: inner runs hotter than outer at baseline, lights add a little heat
  const lightsHeat = (actuators.storage_lights ? 0.15 : 0) + (actuators.croom_lights ? 0.1 : 0) + (actuators.green_area_lights ? 0.15 : 0);
  const greenhouseOffset = 4.5 * (1 - roofOpen * 0.6) + lightsHeat;
  const targetInnerTemp = state.outerTemp + greenhouseOffset;
  state.innerTemp = lerp(state.innerTemp, targetInnerTemp, ventFactor) + noise(0.1);

  // fans + venting also pull inner humidity toward outer humidity, pump raises it
  const pumpHumidity = actuators.water_pump ? 1.0 : 0;
  const targetInnerHumidity = state.outerHumidity - 5 + pumpHumidity * 6;
  state.innerHumidity = clamp(lerp(state.innerHumidity, targetInnerHumidity, ventFactor + 0.05) + noise(0.4), 10, 100);

  // ---- inner brightness: filtered outdoor light + artificial lights ----
  const artificialLight = ((actuators.storage_lights ? 18 : 0) + (actuators.croom_lights ? 12 : 0) + (actuators.green_area_lights ? 20 : 0));
  const targetInnerBrightness = clamp(state.ldrOuter * 0.55 + artificialLight, 0, 100);
  state.ldrInner = clamp(lerp(state.ldrInner, targetInnerBrightness, 0.2) + noise(1), 0, 100);

  // ---- pressure: slow drift, inner slightly higher (sealed structure) ----
  state.outerPressure = clamp(state.outerPressure + noise(0.08) + (state.isRaining ? -0.02 : 0.005), 995, 1025);
  state.innerPressure = clamp(state.outerPressure + 0.4 + noise(0.05), 995, 1026);

  // ---- water levels: pump fills reservoirs, natural slow consumption otherwise, rain tops up slightly ----
  const pumpFill = actuators.water_pump ? 1.4 : 0;
  const rainTopUp = state.isRaining ? 0.15 : 0;
  const consumption = 0.12;
  state.waterLevel1 = clamp(state.waterLevel1 + pumpFill + rainTopUp - consumption + noise(0.3), 0, 100);
  state.waterLevel2 = clamp(state.waterLevel2 + pumpFill * 0.9 + rainTopUp - consumption + noise(0.3), 0, 100);

  // ---- gas: noisy baseline with occasional spike events (useful for anomaly-detection research) ----
  const spikeChance = Math.random() < 0.015;
  const targetGas = spikeChance ? 900 + noise(150) : 400 + noise(20);
  state.gasPpm = clamp(lerp(state.gasPpm, targetGas, spikeChance ? 0.6 : 0.1), 300, 1200);
}

function toRaw12bit(percent) {
  // Rough ADC1 approximation (12-bit, 0-4095) purely for realism in the payload.
  return Math.round(clamp(percent, 0, 100) / 100 * 4095);
}

function buildPayload() {
  return {
    device_id: DEVICE_ID,
    timestamp: new Date().toISOString(),
    sensors: {
      rain: { raw: toRaw12bit(100 - state.rainPercent), percent: Math.round(state.rainPercent) },
      gas_mq135: { raw: toRaw12bit(clamp(state.gasPpm / 12, 0, 100)), ppm_estimate: Math.round(state.gasPpm) },
      water_level_1: { raw: toRaw12bit(state.waterLevel1), percent: Math.round(state.waterLevel1) },
      water_level_2: { raw: toRaw12bit(state.waterLevel2), percent: Math.round(state.waterLevel2) },
      ldr_inner: { raw: toRaw12bit(state.ldrInner), percent: Math.round(state.ldrInner) },
      ldr_outer: { raw: toRaw12bit(state.ldrOuter), percent: Math.round(state.ldrOuter) },
      dht11_inner: { temp_c: Number(state.innerTemp.toFixed(1)), humidity_pct: Math.round(state.innerHumidity) },
      dht11_outer: { temp_c: Number(state.outerTemp.toFixed(1)), humidity_pct: Math.round(state.outerHumidity) },
      bmp280_inner: { pressure_hpa: Number(state.innerPressure.toFixed(1)), temp_c: Number((state.innerTemp - 0.3).toFixed(1)), altitude_m: 55 },
      bmp280_outer: { pressure_hpa: Number(state.outerPressure.toFixed(1)), temp_c: Number(state.outerTemp.toFixed(1)), altitude_m: 55 },
    },
  };
}

async function sendReading(payload) {
  try {
    const res = await fetch(`${SERVER_URL}/api/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  } catch (err) {
    console.error("[mock-esp32] failed to send reading:", err.message);
  }
}

async function tick() {
  await pollActuators();
  tickPhysics();
  const payload = buildPayload();
  await sendReading(payload);
  console.log(
    `[mock-esp32] in:${payload.sensors.dht11_inner.temp_c}C/${payload.sensors.dht11_inner.humidity_pct}% ` +
    `out:${payload.sensors.dht11_outer.temp_c}C/${payload.sensors.dht11_outer.humidity_pct}% ` +
    `rain:${payload.sensors.rain.percent}% gas:${payload.sensors.gas_mq135.ppm_estimate}ppm ` +
    `water:${payload.sensors.water_level_1.percent}/${payload.sensors.water_level_2.percent}% ` +
    `fans:${actuators.south_fan?1:0}/${actuators.north_fan?1:0} pump:${actuators.water_pump?1:0}`
  );
}

console.log(`[mock-esp32] device_id=${DEVICE_ID} target=${SERVER_URL} tick=${TICK_MS}ms day_cycle=${DAY_CYCLE_MIN}min`);
tick();
setInterval(tick, TICK_MS);
