# SDIGF — Smart Decentralized Greenhouse (Research Prototype Stack)

نظام كامل جاهز للأبحاث، بديل مؤقت عن ال-ESP32 الفعلي، مبني على نفس مخطط الحساسات
والمتحكمات الموثّق في `SDIGFProjectdocuementaion.pdf` (Phase 1 — Wiring & Hardware).

```
smart-greenhouse/
├── server/           # سيرفر Node.js الرئيسي: API + لوحة تحكم (dashboard)
├── mock-esp32/        # محاكي يرسل بيانات مطابقة لما سيرسله ESP32 الحقيقي
├── mcp-server/         # MCP server يعطي Claude أدوات القراءة والتحكم
└── README.md
```

## البنية المعمارية

```
[mock-esp32 (أو ESP32 حقيقي لاحقاً)]
        │  POST /api/ingest   (كل 4 ثوانٍ)
        │  GET  /api/actuators (يسحب الحالة المطلوبة للمتحكمات)
        ▼
[server: Node.js + Express + SQLite]
        │  REST API + SSE stream
        ▼                              ▲
[Dashboard (متصفح)]          [mcp-server: stdio MCP]
  عرض + تحكم يدوي                  أدوات لـ Claude:
                                    - قراءة الحساسات (حالياً/تاريخياً)
                                    - التحكم بالمتحكمات (فردي/جماعي)
                                    - تسجيل سيناريوهات بحثية
```

كل من `mock-esp32` و`mcp-server` يتحدثان مع `server` عبر نفس REST API فقط —
لذلك عند توفر ال-ESP32 الحقيقي، تستبدل `mock-esp32` بالفيرموير الفعلي (بنفس
شكل JSON) دون أي تعديل على السيرفر أو على MCP server.

## عقد البيانات (JSON Contract)

### إرسال قراءات (`POST /api/ingest`) — من ESP32 أو المحاكي

```json
{
  "device_id": "esp32-mock-01",
  "timestamp": "2026-08-12T11:38:07.708Z",
  "sensors": {
    "rain":          { "raw": 4095, "percent": 0 },
    "gas_mq135":      { "raw": 1370, "ppm_estimate": 401 },
    "water_level_1":   { "raw": 2031, "percent": 50 },
    "water_level_2":    { "raw": 1826, "percent": 45 },
    "ldr_inner":         { "raw": 1408, "percent": 34 },
    "ldr_outer":          { "raw": 2101, "percent": 51 },
    "dht11_inner":         { "temp_c": 33.1, "humidity_pct": 57 },
    "dht11_outer":          { "temp_c": 28.3, "humidity_pct": 51 },
    "bmp280_inner":          { "pressure_hpa": 1010.4, "temp_c": 32.8, "altitude_m": 55 },
    "bmp280_outer":           { "pressure_hpa": 1010.0, "temp_c": 28.3, "altitude_m": 55 }
  }
}
```

### حالة المتحكمات (`GET/POST /api/actuators`)

| المفتاح | النوع | القيم | GPIO (حسب التوثيق) |
|---|---|---|---|
| south_fan | binary | true/false | GPIO19 |
| north_fan | binary | true/false | GPIO4 |
| storage_lights | binary | true/false | GPIO18 |
| croom_lights | binary | true/false | GPIO5 |
| green_area_lights | binary | true/false | GPIO17 |
| water_pump | binary | true/false | GPIO16 |
| window_servo | servo | 0–180 | GPIO27 |
| roof_servo | servo | 0–180 | GPIO23 |

## التشغيل

يتطلب Node.js 18+ (تم الاختبار على v22).

### 1) السيرفر الرئيسي (Dashboard + API)

```bash
cd server
npm install
npm start        # http://localhost:3000
```

### 2) محاكي ESP32 (بديل مؤقت للـ hardware)

في نافذة طرفية أخرى:

```bash
cd mock-esp32
npm install       # لا يوجد تبعيات فعلية، فقط للتوثيق
npm start
```

متغيرات بيئية اختيارية:
- `SDIGF_SERVER_URL` (افتراضي `http://localhost:3000`)
- `SDIGF_DEVICE_ID` (افتراضي `esp32-mock-01`)
- `SDIGF_TICK_MS` (افتراضي `4000`)
- `SDIGF_DAY_CYCLE_MINUTES` (افتراضي `20` — مدة دورة نهار/ليل مضغوطة للاختبار)

المحاكي يحاكي فيزياء بسيطة: الحرارة/الرطوبة الداخلية تتأثر بالمراوح وفتحة السقف
والنوافذ، الإضاءة الداخلية تزيد مع تشغيل اللمبات، المطر عشوائي ويرفع الرطوبة
الخارجية، المضخة ترفع مستوى الماء تدريجياً، وحساس الغاز يصدر ارتفاعات عشوائية
("events") مفيدة لسيناريوهات اكتشاف الشذوذ.

### 3) MCP server (تحكم Claude)

```bash
cd mcp-server
npm install
npm start   # يعمل عبر stdio، مخصص ليُستدعى من Claude Desktop / Claude Code
```

لربطه بـ Claude Desktop، أضف إلى `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "sdigf-greenhouse": {
      "command": "node",
      "args": ["/المسار-الكامل/smart-greenhouse/mcp-server/index.js"],
      "env": { "SDIGF_SERVER_URL": "http://localhost:3000" }
    }
  }
}
```

### 4) لوحة التحكم

افتح `http://localhost:3000` — تعرض قراءات حية (تُحدَّث لحظياً عبر SSE)،
تحكم يدوي بكل متحكم (مفاتيح للمراوح/الأضواء/المضخة، شريط تمرير للسيرفوهات)،
وسجل الأحداث (تغييرات المتحكمات + سيناريوهات Claude البحثية).

## أدوات MCP المتاحة لـ Claude

| الأداة | الوظيفة |
|---|---|
| `get_latest_reading` | آخر قراءة كاملة للحساسات |
| `get_sensor_history` | سجل تاريخي، مع إمكانية تحديد حساس واحد (مثلاً `dht11_inner.temp_c`) |
| `get_actuator_state` | الحالة الحالية لكل متحكم + آخر تحديث |
| `get_actuator_log` | سجل تغييرات المتحكمات |
| `set_actuator` | التحكم بمتحكم واحد |
| `set_multiple_actuators` | تطبيق عدة تغييرات دفعة واحدة (سيناريو تهوية مثلاً) |
| `log_research_scenario` | تسجيل بداية/ملاحظة سيناريو بحثي في السجل المشترك |
| `get_research_scenario_log` | استرجاع سجل السيناريوهات البحثية |
| `get_greenhouse_schema` | مخطط الحساسات والمتحكمات (المصادر: GPIO، النوع، المدى) |

## ملاحظات للانتقال إلى الـ ESP32 الحقيقي

- استبدل `mock-esp32/simulator.js` بفيرموير حقيقي يرسل نفس بنية JSON إلى
  `POST /api/ingest`، ويستقصي (`poll`) `GET /api/actuators` بنفس الشكل
  للتحكم الفعلي بالريلاي/السيرفو.
- عند إضافة MQTT لاحقاً (كما هو مخطط في توثيق الهاردوير)، يمكن إضافة جسر
  (bridge) بسيط يترجم رسائل MQTT من/إلى نفس REST endpoints دون تعديل
  السيرفر أو MCP server.
- قاعدة البيانات SQLite (`server/greenhouse.db`) تحفظ كل القراءات التاريخية
  وسجل تغييرات المتحكمات والسيناريوهات، بشكل مستقل عن إعادة تشغيل السيرفر.
