import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import { ACTUATOR_KEYS, defaultActuatorState } from "./schema.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.SDIGF_DB_PATH || path.join(__dirname, "..", "greenhouse.db");

export const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS readings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id TEXT NOT NULL,
  ts TEXT NOT NULL,
  payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings(ts);

CREATE TABLE IF NOT EXISTS actuator_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  updated_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS actuator_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  actuator TEXT NOT NULL,
  value TEXT NOT NULL,
  source TEXT NOT NULL,
  note TEXT
);

CREATE TABLE IF NOT EXISTS scenario_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  name TEXT NOT NULL,
  note TEXT
);
`);

// Seed actuator_state with defaults if empty
const seedDefaults = defaultActuatorState();
const insertDefault = db.prepare(
  "INSERT OR IGNORE INTO actuator_state (key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)"
);
const now = new Date().toISOString();
for (const key of ACTUATOR_KEYS) {
  insertDefault.run(key, JSON.stringify(seedDefaults[key]), now, "system-init");
}

// ---- Readings ----
const insertReadingStmt = db.prepare(
  "INSERT INTO readings (device_id, ts, payload) VALUES (?, ?, ?)"
);
export function insertReading(deviceId, ts, sensors) {
  const info = insertReadingStmt.run(deviceId, ts, JSON.stringify(sensors));
  return info.lastInsertRowid;
}

export function getLatestReading() {
  const row = db
    .prepare("SELECT * FROM readings ORDER BY id DESC LIMIT 1")
    .get();
  if (!row) return null;
  return { id: row.id, device_id: row.device_id, ts: row.ts, sensors: JSON.parse(row.payload) };
}

export function getReadingHistory({ limit = 100, sensor = null } = {}) {
  const rows = db
    .prepare("SELECT * FROM readings ORDER BY id DESC LIMIT ?")
    .all(Math.min(limit, 2000));
  const parsed = rows
    .map((r) => ({ id: r.id, device_id: r.device_id, ts: r.ts, sensors: JSON.parse(r.payload) }))
    .reverse();
  if (!sensor) return parsed;
  // sensor can be dotted path e.g. "dht11_inner.temp_c"
  const parts = sensor.split(".");
  return parsed.map((r) => {
    let v = r.sensors;
    for (const p of parts) v = v?.[p];
    return { ts: r.ts, value: v };
  });
}

// ---- Actuators ----
export function getActuatorState() {
  const rows = db.prepare("SELECT * FROM actuator_state").all();
  const state = {};
  for (const row of rows) {
    state[row.key] = JSON.parse(row.value);
  }
  return state;
}

export function getActuatorMeta() {
  const rows = db.prepare("SELECT * FROM actuator_state").all();
  const meta = {};
  for (const row of rows) {
    meta[row.key] = { value: JSON.parse(row.value), updated_at: row.updated_at, updated_by: row.updated_by };
  }
  return meta;
}

const upsertActuatorStmt = db.prepare(`
  INSERT INTO actuator_state (key, value, updated_at, updated_by)
  VALUES (@key, @value, @updated_at, @updated_by)
  ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at, updated_by=excluded.updated_by
`);
const insertLogStmt = db.prepare(
  "INSERT INTO actuator_log (ts, actuator, value, source, note) VALUES (?, ?, ?, ?, ?)"
);

export function setActuator(key, value, source = "unknown", note = null) {
  const ts = new Date().toISOString();
  upsertActuatorStmt.run({ key, value: JSON.stringify(value), updated_at: ts, updated_by: source });
  insertLogStmt.run(ts, key, JSON.stringify(value), source, note);
  return { key, value, updated_at: ts, updated_by: source };
}

export function getActuatorLog(limit = 50) {
  return db.prepare("SELECT * FROM actuator_log ORDER BY id DESC LIMIT ?").all(limit).reverse();
}

// ---- Scenarios (for research runs triggered by Claude via MCP) ----
const insertScenarioStmt = db.prepare(
  "INSERT INTO scenario_log (ts, name, note) VALUES (?, ?, ?)"
);
export function logScenario(name, note = null) {
  const ts = new Date().toISOString();
  insertScenarioStmt.run(ts, name, note);
  return { ts, name, note };
}
export function getScenarioLog(limit = 50) {
  return db.prepare("SELECT * FROM scenario_log ORDER BY id DESC LIMIT ?").all(limit).reverse();
}
