import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import {
  insertReading,
  getLatestReading,
  getReadingHistory,
  getActuatorState,
  getActuatorMeta,
  setActuator,
  getActuatorLog,
  logScenario,
  getScenarioLog,
} from "./db.js";
import { ACTUATOR_DEFS, ACTUATOR_KEYS, SENSOR_KEYS, validateActuatorValue } from "./schema.js";
import { sseHandler, broadcast } from "./events.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

// ---------- Health / schema ----------
app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "sdigf-server", time: new Date().toISOString() });
});

app.get("/api/schema", (req, res) => {
  res.json({ sensors: SENSOR_KEYS, actuators: ACTUATOR_DEFS });
});

// ---------- Ingest (called by real ESP32 or the mock simulator) ----------
app.post("/api/ingest", (req, res) => {
  const { device_id, timestamp, sensors } = req.body || {};
  if (!device_id || !sensors) {
    return res.status(400).json({ ok: false, error: "device_id and sensors are required" });
  }
  const ts = timestamp || new Date().toISOString();
  const id = insertReading(device_id, ts, sensors);
  const reading = { id, device_id, ts, sensors };
  broadcast("reading", reading);
  res.json({ ok: true, id });
});

// ---------- Sensor reads ----------
app.get("/api/sensors/latest", (req, res) => {
  const reading = getLatestReading();
  res.json({ ok: true, reading });
});

app.get("/api/sensors/history", (req, res) => {
  const limit = parseInt(req.query.limit || "100", 10);
  const sensor = req.query.sensor || null;
  const history = getReadingHistory({ limit, sensor });
  res.json({ ok: true, count: history.length, history });
});

// ---------- Actuators ----------
// GET current desired state — used both by the dashboard AND polled by the
// ESP32 / mock simulator to know what to actually switch.
app.get("/api/actuators", (req, res) => {
  res.json({ ok: true, state: getActuatorState() });
});

app.get("/api/actuators/meta", (req, res) => {
  res.json({ ok: true, meta: getActuatorMeta() });
});

app.get("/api/actuators/log", (req, res) => {
  const limit = parseInt(req.query.limit || "50", 10);
  res.json({ ok: true, log: getActuatorLog(limit) });
});

// Set one actuator. source = "dashboard" | "claude-mcp" | "system" ...
app.post("/api/actuators/:key", (req, res) => {
  const { key } = req.params;
  const { value, source = "dashboard", note = null } = req.body || {};
  const check = validateActuatorValue(key, value);
  if (!check.ok) {
    return res.status(400).json({ ok: false, error: check.error });
  }
  const result = setActuator(key, check.value, source, note);
  broadcast("actuator", result);
  res.json({ ok: true, result });
});

// ---------- Scenario log (research runs driven by Claude) ----------
app.post("/api/scenarios/log", (req, res) => {
  const { name, note = null } = req.body || {};
  if (!name) return res.status(400).json({ ok: false, error: "name is required" });
  const entry = logScenario(name, note);
  broadcast("scenario", entry);
  res.json({ ok: true, entry });
});

app.get("/api/scenarios/log", (req, res) => {
  const limit = parseInt(req.query.limit || "50", 10);
  res.json({ ok: true, log: getScenarioLog(limit) });
});

// ---------- Live stream for the dashboard ----------
app.get("/api/stream", sseHandler);

app.listen(PORT, () => {
  console.log(`[sdigf-server] listening on http://localhost:${PORT}`);
  console.log(`[sdigf-server] dashboard:  http://localhost:${PORT}/`);
  console.log(`[sdigf-server] actuators:  ${ACTUATOR_KEYS.join(", ")}`);
});
