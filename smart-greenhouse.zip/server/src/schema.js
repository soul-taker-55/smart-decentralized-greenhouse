// Smart Decentralized Greenhouse — canonical device schema
// Derived from: SDIGF Hardware & Wiring Documentation (Phase 1, v1.0)
// Mirrors exactly what the real ESP32-WROOM-32E is wired to read/drive,
// so the mock simulator and the real firmware can be swapped transparently.

export const SENSOR_KEYS = [
  "rain",            // MH-RD rain sensor, GPIO36 (ADC1), % + raw
  "gas_mq135",        // MQ-135 gas/air-quality, GPIO39 (ADC1, via divider)
  "water_level_1",    // Water level #1, GPIO34 (ADC1)
  "water_level_2",    // Water level #2, GPIO35 (ADC1)
  "ldr_inner",         // LDR inner, GPIO32 (ADC1)
  "ldr_outer",         // LDR outer, GPIO33 (ADC1)
  "dht11_inner",       // DHT11 inner temp/humidity, GPIO25
  "dht11_outer",       // DHT11 outer temp/humidity, GPIO26
  "bmp280_inner",      // BMP280 inner, I2C 0x76
  "bmp280_outer"       // BMP280 outer, I2C 0x77
];

export const ACTUATOR_DEFS = {
  south_fan:         { type: "binary", pin: "GPIO19", label: "South Fan" },
  storage_lights:    { type: "binary", pin: "GPIO18", label: "Storage Lights" },
  croom_lights:      { type: "binary", pin: "GPIO5",  label: "Control Room Lights" },
  green_area_lights: { type: "binary", pin: "GPIO17", label: "Green Area Lights" },
  water_pump:        { type: "binary", pin: "GPIO16", label: "Water Pump" },
  north_fan:         { type: "binary", pin: "GPIO4",  label: "North Fan" },
  window_servo:      { type: "servo",  pin: "GPIO27", label: "Side Windows (pair)", min: 0, max: 180 },
  roof_servo:        { type: "servo",  pin: "GPIO23", label: "Roof Opening", min: 0, max: 180 }
};

export const ACTUATOR_KEYS = Object.keys(ACTUATOR_DEFS);

export function defaultActuatorState() {
  const state = {};
  for (const [key, def] of Object.entries(ACTUATOR_DEFS)) {
    state[key] = def.type === "binary" ? false : 0;
  }
  return state;
}

export function validateActuatorValue(key, value) {
  const def = ACTUATOR_DEFS[key];
  if (!def) return { ok: false, error: `unknown actuator: ${key}` };
  if (def.type === "binary") {
    if (typeof value !== "boolean") return { ok: false, error: `${key} expects boolean` };
    return { ok: true, value };
  }
  if (def.type === "servo") {
    const n = Number(value);
    if (Number.isNaN(n)) return { ok: false, error: `${key} expects a number` };
    const clamped = Math.max(def.min, Math.min(def.max, Math.round(n)));
    return { ok: true, value: clamped };
  }
  return { ok: false, error: "unhandled actuator type" };
}
