#!/usr/bin/env node
// SDIGF MCP Server
// Exposes the Smart Decentralized Greenhouse (real ESP32 or the mock
// simulator, transparently — both talk to the same Node.js server) to
// Claude as a set of tools: read live/historical sensor data, drive
// actuators, and log research scenarios/notes for the experiment trail.

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const SERVER_URL = process.env.SDIGF_SERVER_URL || "http://localhost:3000";

const ACTUATOR_KEYS = [
  "south_fan",
  "north_fan",
  "storage_lights",
  "croom_lights",
  "green_area_lights",
  "water_pump",
  "window_servo",
  "roof_servo",
];

async function apiGet(pathname) {
  const res = await fetch(`${SERVER_URL}${pathname}`);
  if (!res.ok) throw new Error(`GET ${pathname} -> HTTP ${res.status}`);
  return res.json();
}

async function apiPost(pathname, body) {
  const res = await fetch(`${SERVER_URL}${pathname}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`POST ${pathname} -> HTTP ${res.status}: ${data.error || "unknown error"}`);
  return data;
}

function textResult(obj) {
  return { content: [{ type: "text", text: JSON.stringify(obj, null, 2) }] };
}

const server = new McpServer({
  name: "sdigf-greenhouse",
  version: "1.0.0",
  title: "Smart Decentralized Greenhouse",
  description:
    "Control and read the Smart Decentralized Greenhouse (SDIGF). Backed by an ESP32-WROOM-32E " +
    "(or a physics-based mock simulator while hardware is offline) via a Node.js server.",
});

// ---------------- Sensor reads ----------------

server.registerTool(
  "get_latest_reading",
  {
    title: "Get latest sensor reading",
    description:
      "Returns the most recent full sensor snapshot from the greenhouse: rain, gas (MQ-135), " +
      "two water levels, two LDR light sensors, inner/outer DHT11 temp+humidity, and inner/outer " +
      "BMP280 pressure/temp/altitude.",
    inputSchema: {},
  },
  async () => {
    const data = await apiGet("/api/sensors/latest");
    return textResult(data.reading || { message: "no readings yet" });
  }
);

server.registerTool(
  "get_sensor_history",
  {
    title: "Get sensor history",
    description:
      "Returns recent historical readings. Optionally pass a dotted sensor path (e.g. " +
      "'dht11_inner.temp_c', 'water_level_1.percent', 'gas_mq135.ppm_estimate') to get just that " +
      "series of {ts, value} points instead of full snapshots — useful for trend/anomaly analysis.",
    inputSchema: {
      limit: z.number().int().min(1).max(2000).optional().describe("Max number of points to return (default 100)"),
      sensor: z
        .string()
        .optional()
        .describe("Dotted path into the sensor payload, e.g. 'dht11_inner.temp_c'. Omit for full snapshots."),
    },
  },
  async ({ limit, sensor }) => {
    const qs = new URLSearchParams();
    if (limit) qs.set("limit", String(limit));
    if (sensor) qs.set("sensor", sensor);
    const data = await apiGet(`/api/sensors/history?${qs.toString()}`);
    return textResult(data);
  }
);

// ---------------- Actuator reads ----------------

server.registerTool(
  "get_actuator_state",
  {
    title: "Get actuator state",
    description:
      "Returns the current commanded state of every actuator: 6 binary relays (fans, lights, pump) " +
      "and 2 servos (side windows 0-180°, roof 0-180°). This is the desired/target state — the mock " +
      "simulator (or real ESP32) applies it on its next poll cycle.",
    inputSchema: {},
  },
  async () => {
    const data = await apiGet("/api/actuators/meta");
    return textResult(data.meta);
  }
);

server.registerTool(
  "get_actuator_log",
  {
    title: "Get actuator change log",
    description: "Returns the recent history of actuator changes, including who/what issued each command (dashboard, claude-mcp, etc).",
    inputSchema: {
      limit: z.number().int().min(1).max(500).optional().describe("Max entries (default 50)"),
    },
  },
  async ({ limit }) => {
    const qs = limit ? `?limit=${limit}` : "";
    const data = await apiGet(`/api/actuators/log${qs}`);
    return textResult(data.log);
  }
);

// ---------------- Actuator control ----------------

server.registerTool(
  "set_actuator",
  {
    title: "Set an actuator",
    description:
      `Command a single actuator. Binary relays (${ACTUATOR_KEYS.filter((k) => !k.endsWith("_servo")).join(", ")}) ` +
      `take true/false. Servos (window_servo, roof_servo) take an angle 0-180. ` +
      "This writes to the same desired-state store the physical/mock ESP32 polls, so changes take effect " +
      "within one poll cycle (a few seconds).",
    inputSchema: {
      key: z.enum(ACTUATOR_KEYS).describe("Which actuator to set"),
      value: z
        .union([z.boolean(), z.number()])
        .describe("true/false for relays, 0-180 for servos"),
      note: z.string().optional().describe("Optional short note on why this change was made (for the research log)"),
    },
  },
  async ({ key, value, note }) => {
    const data = await apiPost(`/api/actuators/${key}`, { value, source: "claude-mcp", note });
    return textResult(data.result);
  }
);

server.registerTool(
  "set_multiple_actuators",
  {
    title: "Set multiple actuators at once",
    description:
      "Apply several actuator changes together (e.g. open the roof and turn on both fans for a ventilation " +
      "scenario). Each entry is {key, value}. Returns the result of every individual change.",
    inputSchema: {
      changes: z
        .array(
          z.object({
            key: z.enum(ACTUATOR_KEYS),
            value: z.union([z.boolean(), z.number()]),
          })
        )
        .min(1),
      note: z.string().optional().describe("Optional shared note applied to every change in this batch"),
    },
  },
  async ({ changes, note }) => {
    const results = [];
    for (const change of changes) {
      const data = await apiPost(`/api/actuators/${change.key}`, {
        value: change.value,
        source: "claude-mcp",
        note,
      });
      results.push(data.result);
    }
    return textResult(results);
  }
);

// ---------------- Research scenario logging ----------------

server.registerTool(
  "log_research_scenario",
  {
    title: "Log a research scenario",
    description:
      "Record a marker in the shared scenario log (visible on the dashboard) describing a research " +
      "run you are starting or a hypothesis you are testing — e.g. 'heat-stress ventilation test: " +
      "closing roof + fans off for 5 min to observe inner temp rise'. Use this before/after making " +
      "actuator changes for an experiment so the readings can be correlated with intent later.",
    inputSchema: {
      name: z.string().describe("Short scenario name, e.g. 'ventilation-response-test'"),
      note: z.string().optional().describe("Free-text detail: hypothesis, expected outcome, parameters, etc."),
    },
  },
  async ({ name, note }) => {
    const data = await apiPost("/api/scenarios/log", { name, note });
    return textResult(data.entry);
  }
);

server.registerTool(
  "get_research_scenario_log",
  {
    title: "Get research scenario log",
    description: "Returns recently logged research scenarios/markers, most recent last.",
    inputSchema: {
      limit: z.number().int().min(1).max(500).optional(),
    },
  },
  async ({ limit }) => {
    const qs = limit ? `?limit=${limit}` : "";
    const data = await apiGet(`/api/scenarios/log${qs}`);
    return textResult(data.log);
  }
);

// ---------------- Schema / discovery ----------------

server.registerTool(
  "get_greenhouse_schema",
  {
    title: "Get greenhouse hardware schema",
    description:
      "Returns the canonical list of sensor keys and actuator definitions (pins, types, ranges) as wired " +
      "per the hardware documentation. Useful context before planning a scenario.",
    inputSchema: {},
  },
  async () => {
    const data = await apiGet("/api/schema");
    return textResult(data);
  }
);

const transport = new StdioServerTransport();
await server.connect(transport);
console.error(`[sdigf-mcp] connected — proxying to ${SERVER_URL}`);
